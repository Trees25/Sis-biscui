# 🏢 Manual de Usuario: Sucursal

Bienvenido/a al manual de uso del sistema Biscui para el rol de **Sucursal**. Esta guía te explicará cómo gestionar tus pedidos a fábrica, recibir mercadería, y controlar tu stock y consumos diarios.

---

## 1. Acceso al Sistema
Para ingresar al sistema:
1. Accede a la URL proporcionada por el administrador.
2. Ingresa tus credenciales de acceso (usuario y contraseña de la sucursal).
3. Verás en la esquina superior derecha tu **Rol (Sucursal)** y el **Nombre de tu Sucursal**.

---

## 2. Nuevo Pedido a Fábrica
Esta sección te permite solicitar mercadería a la fábrica para reponer tu stock local.

### 📝 Cómo armar un pedido:
1. Ve a la pestaña **Nuevo Pedido a Fábrica**.
2. Verás un panel con categorías (🍧 Helados, 🍦 Pastelería Helada, 🍰 Pastelería Clásica, 🥐 Viennoiserie, 📦 Térmicos, ✨ Otros).
3. Selecciona la categoría deseada o usa la barra de búsqueda (**"🔍 Buscar producto o sabor..."**) para encontrar lo que necesitas.
4. En la tabla verás la siguiente información:
   - **Producto / Sabor**.
   - **Mi Stock** (lo que tienes actualmente en la sucursal).
   - **Stock Fábrica** (lo que hay disponible para que te envíen).
   - **Consumo Prom. Diario** (una sugerencia de cuánto gastas por día).
5. Haz clic sobre el producto que necesites para sumarlo al carrito (puedes hacer varios clics para sumar más unidades, o editar la cantidad directamente en el carrito de la derecha).
6. **Importante:** Si pides más de lo que hay en "Stock Fábrica", verás un aviso de `⚠️ Excede stock`. El pedido se enviará igual, pero la fábrica sabrá que te debe mercadería y te la mandará cuando la fabriquen.
7. Cuando hayas seleccionado todo, ve al panel **🛒 Resumen del Pedido** a la derecha y haz clic en **"Enviar Pedido a Fábrica"**.

### ✨ Productos "Otros"
Si necesitas insumos o packaging (ej. vasos, cucharitas), ve a la sub-pestaña **Otros**. En la parte inferior, tendrás un formulario **"➕ Agregar Producto Personalizado a 'Otros'"** donde puedes escribir el nombre de lo que necesites, elegir el tipo, y agregarlo al pedido.

---

## 3. Mis Recepciones
Aquí controlas el estado de los pedidos que enviaste y registras la mercadería cuando llega a tu local.

### 📦 Cómo recibir un pedido:
1. Ve a la pestaña **Mis Recepciones**.
2. Verás una lista de tus pedidos con su **Estado** (ej. *Pendiente, Preparado, En Tránsito, Entregado*).
3. Cuando el repartidor llegue con tu mercadería, el pedido estará en estado **En Tránsito**.
4. Haz clic en el botón azul **"Controlar y Recibir"**.
5. Se abrirá una ventana con el detalle de lo que te enviaron. Revisa físicamente que las cantidades coincidan con el remito/sistema.
6. Haz clic en **"Confirmar Recepción"**. Esto sumará automáticamente los productos a tu **Stock Actual**.

---

## 4. Registrar Consumo Diario
Es vital registrar todo lo que vendes, se tira o se consume en la sucursal. Esto mantiene tu stock real y ayuda al sistema a calcular tus consumos promedios para sugerirte mejores pedidos en el futuro.

### 📊 Cómo registrar un consumo o venta:
1. Ve a la pestaña **Registrar Consumo Diario**.
2. Usa el buscador o el menú desplegable para seleccionar el producto o sabor que se consumió.
3. Ingresa la **Cantidad Consumida**. (Ejemplo: si usaste 2 baldes de helado o vendiste 5 porciones de torta, pones ese número).
4. Haz clic en **"Registrar Consumo y Restar de Stock"**. 
5. El sistema descontará esa cantidad inmediatamente de tu inventario local.

---

## 5. Retiro Interno (Exclusivo Casa Central)
Como la sucursal Casa Central se encuentra en la misma ubicación que la Fábrica, cuenta con una funcionalidad especial para retirar mercadería de forma directa, sin necesidad de que intervenga el Transportista.

### 🏢 Cómo realizar un Retiro Interno:
1. Ve a la pestaña **Retiro Interno de Fábrica**.
2. Verás un panel con los productos disponibles en la fábrica.
3. Selecciona los productos que deseas retirar e indica la cantidad.
4. El sistema verificará si hay suficiente stock disponible en fábrica.
5. Al hacer clic en **"Confirmar Retiro"**, el stock se descontará automáticamente de Fábrica y se sumará inmediatamente a tu Stock Actual en Casa Central, sin pasar por los estados de envío ni requerir confirmaciones adicionales.

---

## 6. Mi Stock Actual
Aquí puedes tener una visión general de todo el inventario actual de tu sucursal.

### 📋 Control de inventario:
1. Ve a la pestaña **Mi Stock Actual**.
2. Verás una tabla dividida en categorías (Helados, Pastelería, etc.).
3. Aquí podrás ver la cantidad exacta de unidades o kilos que el sistema registra que tienes en el local.
4. Puedes usar la barra de búsqueda para encontrar un producto específico rápidamente.
5. **Recomendación:** Revisa esta pestaña periódicamente y compárala con tu inventario físico. Si hay diferencias, recuerda registrar los consumos diarios correctamente.

---
*Fin del Manual de Sucursal.*
